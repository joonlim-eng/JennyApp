/**
 * Semantic design tokens — JENNY order app.
 * Multiple selectable themes; the active theme is chosen in SETTING.
 */

const base = {
  text: '#0E1B2C',
  background: '#F5F7FA',
  foreground: '#0E1B2C',
  card: '#FFFFFF',
  cardForeground: '#0E1B2C',
  primaryForeground: '#FFFFFF',
  secondary: '#E8EEF4',
  secondaryForeground: '#122A4A',
  muted: '#EDF1F5',
  mutedForeground: '#5B6B7C',
  accentForeground: '#FFFFFF',
  destructive: '#D6403A',
  destructiveForeground: '#FFFFFF',
  border: '#DDE4EB',
  input: '#DDE4EB',
  success: '#1B8A5A',
  warning: '#C77D0A',
  inCart: '#D6403A',
};

export type Palette = typeof base & {
  tint: string;
  primary: string;
  accent: string;
  totalCard?: string; // TOTAL card default color when it differs from primary
  totalLabel?: string; // "TOTAL" text color inside the card (default: translucent white)
  // HOME action button defaults when they differ from primary/accent/success
  sendBtn?: string;
  sendBtnText?: string;
  sendBtnBorder?: string;
  saveBtn?: string;
  saveBtnBorder?: string;
  loadBtn?: string;
  exportBtn?: string;
  actionBtnText?: string; // label color inside the 4 HOME buttons (default white)
  actionBtnIcon?: string; // icon color inside the 4 HOME buttons (default white)
  cameraBadge?: string;
  departmentToggle?: string;

};

//accent / tint = SEND, ORDER LOAD  #7B7B7B
export const themes: Record<string, Palette> = {
  default: {
    ...base,
    primary: '#263238',
    accent: '#546E7A',
    tint: '#546E7A',
    secondary: '#E7EBED',
    secondaryForeground: '#263238',
  },
  navy: { ...base, primary: '#122A4A', accent: '#0E7C86', tint: '#0E7C86' },

  'super famicom': {
    ...base,
    primary: '#263238',
    accent: '#546E7A',
    tint: '#546E7A',
    secondary: '#E7EBED',
    secondaryForeground: '#263238',   
    sendBtn: '#546E7A',
    saveBtn: '#FED645', 
    loadBtn: '#EB1A1D', 
    cameraBadge:'#3B70C2', 
    departmentToggle: '#3B70C2', 
  },
  plum: {
    ...base,
    primary: '#5A294F',
    accent: '#A6537C',
    tint: '#EBD7E1',
    exportBtn: '#ab8da9',  
    loadBtn: '#91709c',
    secondary: '#a75882', 
    secondaryForeground: '#FFFFFF',
  },
  rose: {
    ...base,
    primary: '#7A1F3D',
    accent: '#C2185B',
    tint: '#C2185B',
    totalCard: '#D5B8B6',
    totalLabel: '#7A1F3D', // matches the JENNY brand title (primary)
    sendBtn: '#E3C2BE',
    loadBtn: '#E3C2BE',
    exportBtn: '#EAD0CC',   //excel color
    saveBtn: '#D2A3A4',
    saveBtnBorder: '#FFD54F', // thin yellow outline on SAVE
    actionBtnText: '#C2185B', // theme magenta (accent)
    actionBtnIcon: '#7A1F3D', // burgundy icons
    secondary: '#F6E3EA',
    secondaryForeground: '#7A1F3D',
  },
  forest: {
    ...base,
    primary: '#1E3D2F',
    accent: '#2E7D32',
    tint: '#2E7D32',
    secondary: '#E4EEE6',
    secondaryForeground: '#1E3D2F',
  },
  pumpkin: {
    ...base,
    background: '#FAF4EB',
    primary: '#D35D14',
    accent: '#D35D14',
    tint: '#D35D14',
    border: '#CBAE9A',
    input: '#CBAE9A',
    totalCard: '#D35D14',
    sendBtn: '#3E7C41',
    exportBtn: '#423225',
    saveBtn: '#D4A373',
    loadBtn: '#DE7A2F',
    secondary: '#EBE2D5',
    secondaryForeground: '#423225',
  },
  christmas: {
    ...base,
    background: '#E8F1F5',
    primary: '#C41E3A',
    accent: '#2563EB',
    tint: '#C41E3A',
    border: '#9BB8D0',
    input: '#C5B9A9',
    totalCard: '#C41E3A',
    sendBtn: '#FFFFFF',
    sendBtnText: '#2563EB',
    sendBtnBorder: '#2563EB',
    exportBtn: '#60A5FA',
    saveBtn: '#FFD54F',
    saveBtnBorder: '#C0C0C0',
    loadBtn: '#1B9C56',
    secondary: '#E5DFD3',
    secondaryForeground: '#1B4D3E',
  },
  blush: {
    ...base,
    primary: '#515151',
    accent: '#ffc0c9',
    tint: '#FDF4FF',
    exportBtn: '#c4c1c1d2',  
    secondary: '#F3E8FF',
    secondaryForeground: '#581C87',
  },
};

export const themeNames = Object.keys(themes);

const colors = {
  light: themes.navy,
  radius: 12,
};

export default colors;
